$(function(){
  $('.nataral-show').fullpage({
  	menu: true,
  	navigation: true
  });    
});